import UIKit


print("Clock Recipe Minecraft")

print("Ingredients")

print("Four Gold", "One Redstone")

print("Items needed - Crafting table")

print("Place the four gold around the redstone in the middle like a cross shape")



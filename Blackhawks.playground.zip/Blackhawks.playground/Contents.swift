import UIKit

//---------------------Height Dictionary----------------------------

var blackHawksHeight: [String: Int] = ["15": 182, 
                                       "89": 187,
                                       "91": 180,
                                       "98": 177,
                                       "43": 175,
                                       "16": 187,
                                       "8": 182,
                                       "58": 190,
                                       "17": 182,
                                       "70": 175]

let allKeysHeight = [String](blackHawksHeight.keys)
let allValuesHeight = [Int](blackHawksHeight.values)

//----------------------Age Dictionary---------------------------

var blackHawksAge: [String: Int] = ["15": 25,
                                    "89": 29,
                                    "91": 26,
                                    "98": 18,
                                    "43": 30,
                                    "16": 28,
                                    "8": 28,
                                    "58": 24,
                                    "17": 36,
                                    "70": 24]

let allKeysAge = [String](blackHawksAge.keys)
var allValuesAge = [Int](blackHawksAge.values)

//---------------Month--------------------------------

var blackHawksMonth: [String: String] = ["15": "Jun",
                                    "89": "Aug",
                                    "91": "Jun",
                                    "98": "Jul",
                                    "43": "Mar",
                                    "16": "Jul",
                                    "8": "Apr",
                                    "58": "Jul",
                                    "17": "Oct",
                                    "70": "Apr"]
//----------------------Country Dictionary-----------------------------

let blackHawksCountry = [ "15": "USA",
                          "89": "CAN",
                          "91": "CAN",
                          "98": "CAN",
                          "43": "USA",
                          "16": "CAN",
                          "8": "USA",
                          "58": "CAN",
                          "17": "USA",
                          "70": "USA"]

//------------------Age Sort---------------------------------

let sortedAge = blackHawksAge.sorted(by: <)
print("From youngest to oldest, ", sortedAge)

//---------------Country Sort--------------------------------



//-----------------Average Age Calc--------------------------

var arraySum1 = allValuesAge.reduce(0, +)

var length1 = allValuesAge.count

var average1 = Double(arraySum1)/Double(length1)

print("The average age of a player is, ", average1)


//--------------------Average Height Calc-----------------------

var arraySum = allValuesHeight.reduce(0, +)

var length = allValuesHeight.count

var average = Double(arraySum)/Double(length)

print("The average of the heights of the players is, ", average)

